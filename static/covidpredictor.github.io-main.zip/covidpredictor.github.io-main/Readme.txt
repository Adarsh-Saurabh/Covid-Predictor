
https://vikasjonwal.github.io/covidpredictor.github.io/survey.html
